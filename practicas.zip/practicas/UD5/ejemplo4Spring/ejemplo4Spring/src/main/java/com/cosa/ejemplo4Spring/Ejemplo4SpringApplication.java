package com.cosa.ejemplo4Spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo4SpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo4SpringApplication.class, args);
	}

}
