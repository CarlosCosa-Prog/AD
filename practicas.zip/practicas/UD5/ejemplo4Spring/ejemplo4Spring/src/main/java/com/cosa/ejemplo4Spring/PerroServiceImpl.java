package com.cosa.ejemplo4Spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class PerroServiceImpl implements PerroService {
    @Autowired
    private PerroRepository pr;
    @Override
    public Optional<Perro> findById(Long id) {
        return pr.findById(id);
    }

    @Override
    public List<Perro> findAll() {
        return (List<Perro>) pr.findAll();
    }

    @Override
    public void savePerro(Perro perro) {
        pr.save(perro);
    }

    @Override
    public Perro updatePerro(Long id, Perro perro) {
        Perro viejo = pr.findById(id).get();
        String raza = perro.getRaza();
        int edad = perro.getEdad();

        if ((raza != null) && !(raza.isEmpty())){
            viejo.setRaza(raza);
        }
        if (Objects.nonNull(edad)){
            viejo.setEdad(edad);
        }
        pr.save(viejo);
        return viejo;
    }

    @Override
    public void deletePerro(Long id) {

    }
}
