package com.cosa.ejemplo4Spring;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface PerroService {

    Optional<Perro> findById(Long id);
    List<Perro> findAll();
    void savePerro(Perro perro);
    Perro updatePerro(Long id, Perro perro);
    void deletePerro(Long id);
}
