package com.cosa.ejemplo4Spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
public class WebController {
    @Autowired
    private PerroServiceImpl psi;

    // curl -X GET localhost:8080/lista/1
    @GetMapping("/lista/{id}")
    public Optional<Perro> findById(@PathVariable Long id) { return psi.findById(id);}

    // curl -X GET localhost:8080/lista
    @GetMapping("/lista")
    public List<Perro> findAll() { return psi.findAll(); }

    // curl -X POST localhost:8080/alta -d '{"raza":"Golden retriever","edad":2}' -H "Content-Type: application/json"
    @PostMapping("/alta")
    public void savePerro(@RequestBody Perro perro) { psi.savePerro(perro);}

    // curl -X PUT localhost:8080/modifica/1 -d '{"edad": 5}' -H "Content-Type: application/json"
    @PutMapping("/modifica/{id}")
    public Perro updatePerro(@PathVariable Long id, @RequestBody Perro perro) { return psi.updatePerro(id, perro);}

    // curl -X DELETE localhost:8080/baja/1
    @DeleteMapping("/baja/{id}")
    public void deletePerro(@PathVariable Long id) { psi.deletePerro(id); }
}
