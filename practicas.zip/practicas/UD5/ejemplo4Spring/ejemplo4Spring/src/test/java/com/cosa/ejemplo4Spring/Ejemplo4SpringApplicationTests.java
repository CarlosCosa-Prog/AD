package com.cosa.ejemplo4Spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejemplo4SpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
