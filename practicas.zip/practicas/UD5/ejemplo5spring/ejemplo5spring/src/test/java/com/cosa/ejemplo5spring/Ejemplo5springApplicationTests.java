package com.cosa.ejemplo5spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejemplo5springApplicationTests {

	@Test
	void contextLoads() {
	}

}
