package com.cosa.ejemplo5spring;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface LibroService {
    Optional<Libro> findById(Long id);
    List<Libro> findAll();
    void saveLibro(Libro libro);
    Libro updateLibro(Long id, Libro libro);
    void deleteLibro(Long id);
}
