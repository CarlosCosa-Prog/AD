package com.cosa.ejemplo5spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
@Service
public class LibroServiceImpl implements LibroService {
    @Autowired
    LibroRepository lr;
    @Override
    public Optional<Libro> findById(Long id) {
        return lr.findById(id);
    }

    @Override
    public List<Libro> findAll() {
        return (List<Libro>) lr.findAll();
    }

    @Override
    public void saveLibro(Libro libro) {
        lr.save(libro);
    }

    @Override
    public Libro updateLibro(Long id, Libro libro) {
        Libro viejo = lr.findById(id).get();
        String titulo = libro.getTitulo();
        String autor = libro.getAutor();
        double precio = libro.getPrecio();

        if ((titulo != null) && !(titulo.isEmpty())){
            viejo.setTitulo(titulo);
        }
        if ((autor != null) && !(autor.isEmpty())){
            viejo.setAutor(autor);
        }
        if (Objects.nonNull(precio)){
            viejo.setPrecio(precio);
        }
        lr.save(viejo);
        return viejo;
    }

    @Override
    public void deleteLibro(Long id) {
        lr.deleteById(id);
    }
}
