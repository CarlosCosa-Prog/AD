package com.cosa.ejemplo5spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class WebController {
    @Autowired
    LibroServiceImpl lsi;

    // curl -X GET localhost:8080/lista/1
    @GetMapping("/lista/{id}")
    public Optional<Libro> findById(@PathVariable Long id){
        return lsi.findById(id);
    }

    // curl -X GET localhost:8080/lista
    @GetMapping("/lista")
    public List<Libro> findAll(){
        return lsi.findAll();
    }

    // curl -X POST localhost:8080/guarda -d '{"titulo":"El quijote","autor":"Miguel de Cervantes","precio":5.99}' -H "Content-Type: application/json"
    @PostMapping("/guarda")
    public void saveLibro(@RequestBody Libro libro){
        lsi.saveLibro(libro);
    }

    // curl -X PUT localhost:8080/modifica/1 -d '{"precio": 10.99}' -H "Content-Type: application/json"
    @PutMapping("/modifica/{id}")
    public Libro updateLibro(@PathVariable Long id, @RequestBody Libro libro){
        return lsi.updateLibro(id, libro);
    }

    // curl -X DELETE localhost:8080/borra/1
    @DeleteMapping("/borra/{id}")
    public void deleteLibro(@PathVariable Long id){
        lsi.deleteLibro(id);
    }

}
