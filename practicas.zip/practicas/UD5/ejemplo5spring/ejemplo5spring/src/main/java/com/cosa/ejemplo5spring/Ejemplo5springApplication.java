package com.cosa.ejemplo5spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo5springApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo5springApplication.class, args);
	}

}
