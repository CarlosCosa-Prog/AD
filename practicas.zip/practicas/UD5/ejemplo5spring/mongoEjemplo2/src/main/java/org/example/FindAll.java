package org.example;

import com.mongodb.client.*;
import org.bson.Document;

public class FindAll {
    public static void main(String[] args) {
        try(MongoClient mc = MongoClients.create("mongodb://localhost:27017")){
            MongoDatabase database = mc.getDatabase("mongo");
            MongoCollection<Document> collection = database.getCollection("libros");

            FindIterable<Document> iterable = collection.find();
            for (Document document : iterable){
                System.out.println(document.toJson());
            }
        }
    }
}
