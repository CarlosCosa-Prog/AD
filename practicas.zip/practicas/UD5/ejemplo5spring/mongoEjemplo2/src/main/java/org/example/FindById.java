package org.example;

import com.mongodb.client.*;
import org.bson.Document;
import org.bson.conversions.Bson;

import java.util.List;

import static com.mongodb.client.model.Filters.eq;

public class FindById {
    public static void main(String[] args) {
        try(MongoClient mc = MongoClients.create("mongodb://localhost:27017")){
            MongoDatabase database = mc.getDatabase("mongo");
            MongoCollection<Document> collection = database.getCollection("libros");

            Bson filter = eq("_id",1);
            FindIterable<Document> iterable =  collection.find(filter);

            for (Document document : iterable){
                System.out.println(document.get("titulo") + " , " + document.get("autor"));
            }
        }
    }
}
