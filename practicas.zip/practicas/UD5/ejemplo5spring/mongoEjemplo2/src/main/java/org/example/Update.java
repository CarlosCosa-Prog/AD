package org.example;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.bson.conversions.Bson;


import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Updates.set;

public class Update {
    public static void main(String[] args) {
        try(MongoClient mc = MongoClients.create("mongodb://localhost:27017")){
            MongoDatabase database = mc.getDatabase("mongo");
            MongoCollection<Document> collection = database.getCollection("libros");

            Bson filter = eq("autor", "Sin especificar");
            Bson update = set("autor", "Manolo el del bombo");
            collection.updateMany(filter, update);
        }
    }
}
