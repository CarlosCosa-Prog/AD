package org.example.mapeado;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.*;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;
import org.bson.conversions.Bson;

import java.util.ArrayList;
import java.util.List;

import static com.mongodb.client.model.Filters.lte;
import static com.mongodb.client.model.Updates.inc;
import static org.bson.codecs.configuration.CodecRegistries.fromProviders;
import static org.bson.codecs.configuration.CodecRegistries.fromRegistries;

public class App {
    public static void main(String[] args) {
        ConnectionString connString = new ConnectionString("mongodb://localhost:27017");
        CodecRegistry pojoCodecRegistry = fromProviders(
                PojoCodecProvider.builder().automatic(true).build());
        CodecRegistry codecRegistry = fromRegistries(
                MongoClientSettings.getDefaultCodecRegistry(), pojoCodecRegistry);
        MongoClientSettings clientSettings = MongoClientSettings.builder()
                .applyConnectionString(connString)
                .codecRegistry(codecRegistry)
                .build();

        try (MongoClient mc = MongoClients.create(clientSettings)){
            MongoDatabase database = mc.getDatabase("mapeado");
            MongoCollection<Pelicula> collection = database.getCollection("peliculas",Pelicula.class);

            /*Pelicula p1 = new Pelicula(1,"Guerra mundial Z", 2013);
            Pelicula p2 = new Pelicula(2,"Train to Busan", 2018);
            collection.insertOne(p1);
            collection.insertOne(p2);*/

            FindIterable<Pelicula> iterable = collection.find();
            for (Pelicula pelicula : iterable){
                System.out.println(pelicula.getTitulo() + " , " + pelicula.getAño());
            }
            /*
            List<Pelicula> lista = new ArrayList<>();
            Pelicula p3 = new Pelicula(3,"The walking dead", 2012);
            Pelicula p4 = new Pelicula(4,"El amanecer de los muertos", 2001);
            lista.add(p3);
            lista.add(p4);
            collection.insertMany(lista);*

            System.out.println("\nDespúes de insertar 2:\n");
            FindIterable<Pelicula> iterable2 = collection.find();
            for (Pelicula pelicula : iterable2){
                System.out.println(pelicula.getTitulo() + " , " + pelicula.getAño());
            }*/
            Bson filter = lte("año", 2012);
            Bson update = inc("año", 5);
            collection.updateMany(filter,update);
            System.out.println("\nDespúes de incrementar los años menores o igual a 2012 en 5");
            FindIterable<Pelicula> iterable3 = collection.find();
            for (Pelicula pelicula : iterable3){
                System.out.println(pelicula.get_id() + " , " + pelicula.getTitulo() + " , " + pelicula.getAño());
            }
        }
    }
}
