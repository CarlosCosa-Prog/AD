package org.example;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class InsertOne {
    public static void main(String[] args) {
        try(MongoClient mc = MongoClients.create("mongodb://localhost:27017")){
            MongoDatabase database = mc.getDatabase("mongo");
            MongoCollection<Document> collection = database.getCollection("libros");

            Document libro = new Document("_id", 1);
            libro.append("titulo", "El quijote").append("autor", "Cervantes").append("precio",5.99);
            collection.insertOne(libro);
            System.out.println("Libro " + libro.toJson() + " añadido correctamente");
        }
    }
}
