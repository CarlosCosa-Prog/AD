package org.example;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class InsertMany {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        try(MongoClient mc = MongoClients.create("mongodb://localhost:27017")){
            MongoDatabase database = mc.getDatabase("mongo");
            MongoCollection<Document> collection = database.getCollection("libros");

            String titulo = "";
            String autor = "";
            double precio = 0;
            List<Document> lista = new ArrayList<Document>();

            for (int i = 2 ; i <= 4 ; i++){
                System.out.println("Escribe el nombre del libro numero " + i + ":");
                titulo = sc.nextLine();
                System.out.println("Escribe el autor del libro numero " + i + ":");
                autor = sc.nextLine();
                System.out.println("Escribe el precio del libro numero " + i + ":");
                precio = Double.parseDouble(sc.nextLine());
                Document libro = new Document("_id", i);
                libro.append("titulo", titulo).append("autor",autor).append("precio",precio);
                System.out.println();   // salto de linea
                lista.add(libro);
            }
            collection.insertMany(lista);

        }
    }
}
