package com.cosa.ejemplo2Spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class PeliculaServiceImpl implements PeliculaService {
    @Autowired
    private PeliculaRespository peliculaRespository;
    @Override
    public Optional<Pelicula> findById(Long id) {
        return peliculaRespository.findById(id);
    }

    @Override
    public List<Pelicula> findAll() {
        return (List<Pelicula>) peliculaRespository.findAll();
    }

    @Override
    public void savePelicula(Pelicula pelicula) {
        peliculaRespository.save(pelicula);
    }

    @Override
    public Pelicula updatePelicula(Long id, Pelicula pelicula) {
        Pelicula vieja = peliculaRespository.findById(id).get();

        String nombre = pelicula.getNombre();
        String director = pelicula.getDirector();
        int año = pelicula.getAño();

        if ((nombre != null) && !(nombre.isEmpty())){
            vieja.setNombre(nombre);
        }

        if ((director != null) && !(director.isEmpty())){
            vieja.setDirector(director);
        }

        if (Objects.nonNull(año)){
            vieja.setAño(año);
        }

        peliculaRespository.save(vieja);
        return vieja;

    }

    @Override
    public void deletePelicula(Long id) {
        peliculaRespository.deleteById(id);
    }
}
