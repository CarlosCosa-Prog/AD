package com.cosa.ejemplo2Spring;

import java.util.List;
import java.util.Optional;

public interface PeliculaService {
    Optional<Pelicula> findById(Long id);
    List<Pelicula> findAll();
    void savePelicula(Pelicula pelicula);
    Pelicula updatePelicula(Long id, Pelicula pelicula);
    void deletePelicula(Long id);
}
