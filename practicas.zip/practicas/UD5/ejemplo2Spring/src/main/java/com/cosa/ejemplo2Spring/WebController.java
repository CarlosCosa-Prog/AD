package com.cosa.ejemplo2Spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class WebController {
    @Autowired
    PeliculaServiceImpl psi;

    @GetMapping("/lista/{id}")
    public Optional<Pelicula> findById(@PathVariable Long id) {return psi.findById(id);}

    @GetMapping("/lista")
    public List<Pelicula> findAll(){return psi.findAll();}

    @PostMapping("/guarda")
    public void savePelicula(@RequestBody Pelicula pelicula){ psi.savePelicula(pelicula);}

    @PutMapping("/modifica/{id}")
    public Pelicula updatePelicula(@PathVariable Long id, @RequestBody Pelicula pelicula){ return psi.updatePelicula(id,pelicula);}

    @DeleteMapping("/borra/{id}")
    public void deletePelicula(@PathVariable Long id){ psi.deletePelicula(id);}
}
