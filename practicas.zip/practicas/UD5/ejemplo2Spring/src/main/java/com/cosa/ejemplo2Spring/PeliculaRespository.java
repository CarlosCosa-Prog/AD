package com.cosa.ejemplo2Spring;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PeliculaRespository extends CrudRepository<Pelicula,Long> {
}
