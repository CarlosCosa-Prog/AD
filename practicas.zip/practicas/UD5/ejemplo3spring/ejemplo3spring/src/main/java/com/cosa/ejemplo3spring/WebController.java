package com.cosa.ejemplo3spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class WebController {
    @Autowired
    private VideojuegoServiceImpl vsi;

    // curl -X GET localhost:8080/lista/1
    @GetMapping("/lista/{id}")
    public Optional<Videojuego> findById(@PathVariable  Long id){ return vsi.findById(id);}

    // curl -X GET localhost:8080/lista
    @GetMapping("/lista")
    public List<Videojuego> findAll() {return vsi.findAll(); }

    // curl -X POST localhost:8080/guarda -d '{"nombre":"God of war 3", "precio":10}' -H "Content-Type: application/json"
    @PostMapping("/guarda")
    public void saveVideojuego(@RequestBody Videojuego videojuego) { vsi.saveVideojuego(videojuego);}

    // curl -X PUT localhost:8080/actualiza/1 -d '{"precio": 30.99}' -H "Content-Type: application/json"
    @PutMapping("/actualiza/{id}")
    public Videojuego updateVideojuego(@PathVariable Long id, @RequestBody Videojuego videojuego) {
        return vsi.updateVideojuego(id,videojuego);
    }

    // curl -X DELETE localhost:8080/borra/1
    @DeleteMapping("/borra/{id}")
    public void deleteVideojuego(@PathVariable Long id) { vsi.deleteVideojuego(id);}
}
