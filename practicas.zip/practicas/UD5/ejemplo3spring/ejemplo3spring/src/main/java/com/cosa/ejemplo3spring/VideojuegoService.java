package com.cosa.ejemplo3spring;

import java.util.List;
import java.util.Optional;

public interface VideojuegoService {
    Optional<Videojuego> findById(Long id);
    List<Videojuego> findAll();
    void saveVideojuego(Videojuego videojuego);
    Videojuego updateVideojuego(Long id, Videojuego videojuego);
    void deleteVideojuego(Long id);
}
