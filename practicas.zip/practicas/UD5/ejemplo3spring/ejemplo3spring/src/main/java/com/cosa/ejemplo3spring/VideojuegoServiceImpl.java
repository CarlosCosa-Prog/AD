package com.cosa.ejemplo3spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class VideojuegoServiceImpl implements VideojuegoService {
    @Autowired
    private VideojuegoRepository videojuegoRepository;
    @Override
    public Optional<Videojuego> findById(Long id) {
        return videojuegoRepository.findById(id);
    }

    @Override
    public List<Videojuego> findAll() {
        return (List<Videojuego>) videojuegoRepository.findAll();
    }

    @Override
    public void saveVideojuego(Videojuego videojuego) {
        videojuegoRepository.save(videojuego);
    }

    @Override
    public Videojuego updateVideojuego(Long id, Videojuego videojuego) {
        Videojuego viejo = videojuegoRepository.findById(id).get();
        String nombre = videojuego.getNombre();
        int precio = videojuego.getPrecio();

        if ((nombre != null) && !(nombre.isEmpty())){
            viejo.setNombre(nombre);
        }
        if (Objects.nonNull(precio)){
            viejo.setPrecio(precio);
        }
        videojuegoRepository.save(viejo);
        return viejo;
    }

    @Override
    public void deleteVideojuego(Long id) {
        videojuegoRepository.deleteById(id);
    }
}
