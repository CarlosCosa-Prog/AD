package com.cosa.ejemplo3spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo3springApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo3springApplication.class, args);
	}

}
