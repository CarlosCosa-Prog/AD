package com.cosa.ejemplo3spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejemplo3springApplicationTests {

	@Test
	void contextLoads() {
	}

}
