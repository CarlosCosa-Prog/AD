package org.example;


import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.*;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;
import org.bson.conversions.Bson;

import java.util.ArrayList;
import java.util.List;

import static com.mongodb.client.model.Filters.eq;
import static org.bson.codecs.configuration.CodecRegistries.fromProviders;
import static org.bson.codecs.configuration.CodecRegistries.fromRegistries;

public class App
{
    public static void main( String[] args ) {
        ConnectionString connString = new ConnectionString("mongodb://localhost:27017");
        CodecRegistry pojoCodecRegistry = fromProviders(
                PojoCodecProvider.builder().automatic(true).build());
        CodecRegistry codecRegistry = fromRegistries(
                MongoClientSettings.getDefaultCodecRegistry(), pojoCodecRegistry);
        MongoClientSettings clientSettings = MongoClientSettings.builder()
                .applyConnectionString(connString)
                .codecRegistry(codecRegistry)
                .build();
        try(MongoClient mc = MongoClients.create(clientSettings)){
            MongoDatabase database = mc.getDatabase("mapeo");
            MongoCollection<Videojuego> collection = database.getCollection("videojuegos", Videojuego.class);

            List<Videojuego> lista = new ArrayList<>();
            Videojuego v1 = new Videojuego(1,"Yakuza kiwami 1", 19.99);
            Videojuego v2 = new Videojuego(2,"Yakuza 0 Directors cut", 49.99);
            lista.add(v1);
            lista.add(v2);
            collection.insertMany(lista);

            MongoCursor<Videojuego> cursor = collection.find().iterator();
            while(cursor.hasNext()){
                System.out.println(cursor.next());
            }

            /*Bson filter = eq("_id", 1);
            collection.deleteOne(filter);*/
        }
    }
}
