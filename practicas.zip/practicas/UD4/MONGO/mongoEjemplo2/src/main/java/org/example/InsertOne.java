package org.example;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class InsertOne {
    public static void main(String[] args) {
        try(MongoClient mc = MongoClients.create("mongodb://localhost:27017")){
            MongoDatabase database = mc.getDatabase("pruebas");
            MongoCollection<Document> collection = database.getCollection("cine");

            Document pelicula = new Document("_id", 1);
            pelicula.append("titulo", "Kill Bill").append("director", "Quentin Tarantino").append("año", 2007);
            System.out.println("Pelicula " + pelicula.toJson() + " añadida correctamente");
            collection.insertOne(pelicula);
        }
    }
}
