package org.example;

import com.mongodb.client.*;
import org.bson.Document;
import org.bson.conversions.Bson;

import java.util.List;

public class FindAll {
    public static void main(String[] args) {
        try(MongoClient mc = MongoClients.create("mongodb://localhost:27017")){
            MongoDatabase database = mc.getDatabase("pruebas");
            MongoCollection<Document> collection = database.getCollection("cine");

            FindIterable<Document> iterable = collection.find();

            for (Document document : iterable)
                System.out.println(document.get("titulo") + " , " + document.get("director") + " , " + document.get("año"));
        }
    }
}
