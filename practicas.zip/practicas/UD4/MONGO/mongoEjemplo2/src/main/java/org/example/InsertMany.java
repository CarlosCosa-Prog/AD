package org.example;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class InsertMany {
    private static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        try(MongoClient mc = MongoClients.create("mongodb://localhost:27017")){
            MongoDatabase database = mc.getDatabase("pruebas");
            MongoCollection<Document> collection = database.getCollection("cine");

            List<Document> lista = new ArrayList<Document>();
            String titulo = "";

            for (int i = 2 ; i < 4 ; i++){
                Document pelicula = new Document("_id", i);
                System.out.println("Introduce el titulo de la pelicula numero " + i + ":");
                titulo = sc.nextLine();
                pelicula.append("titulo",titulo).append("año", 2000);
                lista.add(pelicula);
            }
            collection.insertMany(lista);
        }
    }
}
