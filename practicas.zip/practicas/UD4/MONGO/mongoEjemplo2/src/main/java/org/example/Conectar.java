package org.example;

import com.mongodb.client.MongoClient;
import com.mongodb.client.*;
import org.bson.Document;

public class Conectar {
    public static void main(String[] args) {
        try(MongoClient mc = MongoClients.create("mongodb://localhost:27017")){
            MongoDatabase database = mc.getDatabase("pruebas");
            MongoCollection<Document> collection = database.getCollection("cine");
            System.out.println("Conexion a la base de datos " + collection.getNamespace() + " establecida correctamente.");
        }
    }
}
