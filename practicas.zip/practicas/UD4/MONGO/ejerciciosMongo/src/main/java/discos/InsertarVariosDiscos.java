package discos;

import com.mongodb.client.*;
import org.bson.Document;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class InsertarVariosDiscos {
    // insertar múltiples discos (al menos 2)
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        try (MongoClient mc = MongoClients.create("mongodb://localhost:27017")){
            MongoDatabase database = mc.getDatabase("midb");
            MongoCollection<Document> collection = database.getCollection("discos");

            String titulo = "";
            List<Document> lista = new ArrayList<Document>();
            for (int i = 2 ; i < 4 ; i++){
                Document disco = new Document("id", i);
                System.out.println("Introduce el titulo del disco " + i + ":");
                titulo = sc.nextLine();
                disco.append("titulo",titulo)
                        .append("musico", "System of a Down")
                        .append("genero", "Rock")
                        .append("precio", 19.99);
                lista.add(disco);
            }
            collection.insertMany(lista);
        }
    }
}
