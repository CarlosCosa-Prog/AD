package empleado;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.bson.conversions.Bson;

import static com.mongodb.client.model.Filters.*;
import static com.mongodb.client.model.Filters.eq;

// muestre los empleados que tengan su domicilio en una vía de tipo "Plaza" y su número en la plaza esté entre 3 y 8

public class MuestraEmpleados2 {
    public static void main(String[] args) {
        try (MongoClient mc = MongoClients.create("mongodb://localhost:27017")) {
            MongoDatabase database = mc.getDatabase("midb");
            MongoCollection<Document> collection = database.getCollection("empleados");

            Bson filter = and(eq("direccion.tipoVia","Plaza"),and(lte("direccion.numero",8),gte("direccion.numero",3)));
            Document empleado = collection.find(filter).first();
            System.out.println(empleado);
        }
    }
}
