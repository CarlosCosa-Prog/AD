package empleado;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.bson.conversions.Bson;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static com.mongodb.client.model.Filters.eq;

public class InsertarVariosEmpleados {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        try (MongoClient mc = MongoClients.create("mongodb://localhost:27017")){
            MongoDatabase database = mc.getDatabase("midb");
            MongoCollection<Document> collection = database.getCollection("empleados");

            String nombre = "";
            List<Document> lista = new ArrayList<Document>();
            for (int i = 2 ; i < 4 ; i++){
                Document direccion = new Document("tipoVia","Avenida").append("nombre","Reina Sofia").append("numero",10);
                System.out.println("Introduce el nombre del empleado numero " + i + ":");
                nombre = sc.nextLine();
                Document empleado = new Document("_id", i).append("nombre", nombre).append("dni", "654654D").append("direccion",direccion);
                lista.add(empleado);
            }
            collection.insertMany(lista);
        }
    }
}
