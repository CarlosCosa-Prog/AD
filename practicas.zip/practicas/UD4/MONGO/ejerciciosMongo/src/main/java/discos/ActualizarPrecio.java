package discos;

import com.mongodb.client.*;
import com.mongodb.client.result.UpdateResult;
import org.bson.Document;
import org.bson.conversions.Bson;


import static com.mongodb.client.model.Aggregates.set;
import static com.mongodb.client.model.Filters.*;
import static com.mongodb.client.model.Updates.inc;

/* (listar los discos de precio inferior a 10 o superior a 20) *
   incrementar en 5 euros el precio de los discos de la anterior consulta */
public class ActualizarPrecio {
    public static void main(String[] args) {
        try (MongoClient mc = MongoClients.create("mongodb://localhost:27017")){
            MongoDatabase database = mc.getDatabase("midb");
            MongoCollection<Document> collection = database.getCollection("discos");

            Bson filter = or(lt("precio",10),gt("precio",20));
            Bson update = inc("precio", 5);

            UpdateResult result = collection.updateMany(filter,update);
            System.out.println(result);

        }

    }
}
