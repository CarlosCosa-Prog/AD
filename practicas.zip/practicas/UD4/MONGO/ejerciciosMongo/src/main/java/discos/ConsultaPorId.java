package discos;

import com.mongodb.client.*;
import org.bson.Document;

import static com.mongodb.client.model.Filters.eq;

// listar un disco con un id determinado
public class ConsultaPorId {
    public static void main(String[] args) {
        try (MongoClient mc = MongoClients.create("mongodb://localhost:27017")){
            MongoDatabase database = mc.getDatabase("midb");
            MongoCollection<Document> collection = database.getCollection("discos");

            int cod = 3;
            Document libro = collection.find(eq("id",cod)).first();
            System.out.println("El libro con id " + cod + " es:\n"+libro.get("titulo"));
        }
    }
}
