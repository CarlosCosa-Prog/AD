package discos;

import com.mongodb.client.*;
import com.mongodb.client.model.UpdateOptions;
import org.bson.Document;
import org.bson.conversions.Bson;


import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Updates.combine;
import static com.mongodb.client.model.Updates.set;

// actualiza el disco (7,"Love supreme","John Coltrane","jazz", 25) con un upsert
public class ActualizarDisco {
    public static void main(String[] args) {
        try (MongoClient mc = MongoClients.create("mongodb://localhost:27017")){
            MongoDatabase database = mc.getDatabase("midb");
            MongoCollection<Document> collection = database.getCollection("discos");

            Bson filter = eq("id", 7);
            Bson update = combine(set("titulo","Love supreme")
                                    ,set("musico","John Coltrane")
                                    ,set("genero", "jazz")
                                    ,set("precio", 25));


            UpdateOptions option = new UpdateOptions().upsert(true);

            collection.updateOne(filter,update,option);
        }
    }
}
