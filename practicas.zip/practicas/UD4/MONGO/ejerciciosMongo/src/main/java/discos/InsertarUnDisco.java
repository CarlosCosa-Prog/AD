package discos;

import com.mongodb.client.*;
import org.bson.Document;

public class InsertarUnDisco {
    // insertar un disco
    public static void main(String[] args) {
        try (MongoClient mc = MongoClients.create("mongodb://localhost:27017")) {
            MongoDatabase database = mc.getDatabase("midb");
            MongoCollection<Document> collection = database.getCollection("discos");
            Document libro = new Document("id", 7);
            libro.append("titulo", "PRUEBA")
                    .append("musico", "MUSICO DE PRUEBA")
                    .append("genero", "SIN GENERO")
                    .append("precio", 10.99);
            collection.insertOne(libro);
        }
    }
}
