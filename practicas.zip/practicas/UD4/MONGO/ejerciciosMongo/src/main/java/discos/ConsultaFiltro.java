package discos;

import com.mongodb.client.*;
import org.bson.Document;

import static com.mongodb.client.model.Filters.*;

// listar los discos de precio inferior a 10 o superior a 20
public class ConsultaFiltro {
    public static void main(String[] args) {
        try (MongoClient mc = MongoClients.create("mongodb://localhost:27017")){
            MongoDatabase database = mc.getDatabase("midb");
            MongoCollection<Document> collection = database.getCollection("discos");

            Document libro = collection.find(or(lt("precio",10),gt("precio",20))).first();
            System.out.println(libro.toJson());
        }
    }
}
