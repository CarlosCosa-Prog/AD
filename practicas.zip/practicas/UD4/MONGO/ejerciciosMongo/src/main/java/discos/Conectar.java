package discos;

import com.mongodb.client.*;

public class Conectar {
    public static void main(String[] args) {
        MongoClient mc = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mc.getDatabase("midb");
        MongoCollection collection = database.getCollection("discos");
        System.out.println("Conexión establecida correctamente");
    }
}
