package empleado;

import com.mongodb.client.MongoClient;
import com.mongodb.client.*;
import org.bson.Document;
/*  -id (entero)
    -nombre (String)
    -dni (String)
    -direccion (de tipo Direccion(tipoVia, nombre, numero))*/

public class InsertarUnEmpleado {
    public static void main(String[] args) {
        try(MongoClient mc = MongoClients.create("mongodb://localhost:27017")){
            MongoDatabase database = mc.getDatabase("midb");
            MongoCollection<Document> collection = database.getCollection("empleados");

            Document direccion = new Document("tipoVia","Plaza").append("nombre","Reina Sofia").append("numero",7);
            Document empleado = new Document("_id", 7).append("nombre", "Cuchurrufleta").append("dni", "654654D").append("direccion",direccion);
            collection.insertOne(empleado);
        }
    }
}
